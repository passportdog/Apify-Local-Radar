# Meta Ads Library Scraper - Bright Data Edition

Scrape Meta Ad Library at scale using Bright Data's Scraping Browser.

## Cost

- ~$5.88 per GB of traffic
- ~0.5MB per search query
- **~$0.06 per 1,000 ads**

## Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure

Edit `scraper.ts` and update the CONFIG section:

```typescript
const CONFIG = {
  // Your Bright Data credentials (already set)
  browserWS: 'wss://brd-customer-hl_a4badd60-zone-scraping_browser1:ejngqcqdlyh2@brd.superproxy.io:9222',
  
  // Adjust these based on your needs
  concurrency: 10,        // Parallel browsers
  maxAdsPerQuery: 100,    // Max ads per search
  
  // Optional: Supabase webhook
  webhookUrl: '',  // Add your Supabase function URL
};
```

### 3. Add Your Search Queries

Edit the `queries` array in the `main()` function:

```typescript
const queries: SearchQuery[] = [
  { keyword: 'plumber', location: 'Ocala, FL' },
  { keyword: 'hvac', location: 'Ocala, FL' },
  // Add more...
];
```

### 4. Run

```bash
npm start
```

Or for production:

```bash
npm run build
npm run scrape
```

## Output

- Ads saved to `scraped_ads.json`
- If webhook configured, also sent to Supabase

## Scaling Tips

### Concurrency

- Start with 5-10 concurrent browsers
- Increase gradually up to 20-50
- Monitor Bright Data dashboard for errors

### Large Scale (1M+ ads)

1. Split queries into multiple batches
2. Run from multiple machines
3. Use a cron job or scheduler

### Query Generation

For comprehensive coverage, generate queries programmatically:

```typescript
const services = ['plumber', 'hvac', 'electrician', 'roofing', ...];
const cities = ['Ocala, FL', 'Gainesville, FL', 'Tampa, FL', ...];

const queries = services.flatMap(service => 
  cities.map(city => ({ keyword: service, location: city }))
);
```

## Webhook Integration

To send ads directly to Supabase:

1. Deploy the Edge Function from the Apify project's `supabase/functions/import-ads`
2. Set `webhookUrl` in CONFIG:

```typescript
webhookUrl: 'https://your-project.supabase.co/functions/v1/import-ads',
```

## Troubleshooting

### Connection Refused

- Check Bright Data dashboard for zone status
- Verify credentials are correct

### Timeout Errors

- Increase `timeout` in `page.goto()`
- Reduce concurrency

### No Ads Found

- Check if the search term has results manually
- Try without location filter

### Rate Limited

- Reduce concurrency
- Add delays between batches:

```typescript
// After each batch
await new Promise(r => setTimeout(r, 5000)); // 5 second delay
```

## Cost Tracking

Monitor usage in Bright Data dashboard:
https://brightdata.com/cp/zones

Estimate: 
- 10,000 queries = ~5GB = ~$30
- 100,000 queries = ~50GB = ~$300
- 1,000 ads per query = 10M ads for ~$300
