/**
 * Meta Ads Library Scraper - Bright Data Edition
 * 
 * Run from your local machine with unlimited concurrency
 * Cost: ~$0.06 per 1,000 ads
 */

import puppeteer, { Browser, Page } from 'puppeteer-core';

// ============================================
// CONFIGURATION
// ============================================

const CONFIG = {
  // Bright Data Scraping Browser
  browserWS: 'wss://brd-customer-hl_a4badd60-zone-scraping_browser1:ejngqcqdlyh2@brd.superproxy.io:9222',
  
  // Scraping settings
  concurrency: 10,           // Parallel browsers (adjust based on your plan)
  maxAdsPerQuery: 100,       // Max ads to scrape per search
  scrollAttempts: 10,        // How many times to scroll for more ads
  scrollDelay: 1000,         // ms between scrolls
  
  // Supabase webhook (optional - leave empty to just save locally)
  webhookUrl: '',  // e.g., 'https://your-project.supabase.co/functions/v1/import-ads'
  webhookBatchSize: 50,
  
  // Output
  outputFile: 'scraped_ads.json',
};

// ============================================
// TYPES
// ============================================

interface SearchQuery {
  keyword: string;
  location?: string;
}

interface MetaAd {
  ad_id: string;
  ad_fingerprint: string;
  page_id: string;
  page_name: string;
  page_profile_picture_url: string;
  ad_text: string;
  media_type: 'image' | 'video' | 'carousel' | 'none';
  media_urls: string[];
  cta_text: string;
  ad_delivery_start_time: string;
  is_active: boolean;
  platforms: string[];
  spend_lower?: number;
  spend_upper?: number;
  impressions_lower?: number;
  impressions_upper?: number;
  search_query: string;
  search_location: string;
  scraped_at: string;
  source_url: string;
}

// ============================================
// FINGERPRINT GENERATION
// ============================================

function generateFingerprint(ad: Partial<MetaAd>): string {
  const components = [
    ad.page_id || '',
    ad.page_name || '',
    (ad.ad_text || '').toLowerCase().replace(/\s+/g, ' ').trim().substring(0, 200),
    (ad.media_urls?.[0] || '').split('?')[0],
    (ad.cta_text || '').toLowerCase(),
  ].join('|');
  
  let hash = 0;
  for (let i = 0; i < components.length; i++) {
    const char = components.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  
  return 'meta_' + Math.abs(hash).toString(16).padStart(8, '0');
}

// ============================================
// DEDUPLICATION TRACKER
// ============================================

class DedupeTracker {
  private seen = new Set<string>();
  private dupeCount = 0;
  
  isNew(ad: MetaAd): boolean {
    if (this.seen.has(ad.ad_fingerprint)) {
      this.dupeCount++;
      return false;
    }
    this.seen.add(ad.ad_fingerprint);
    return true;
  }
  
  get stats() {
    return { unique: this.seen.size, duplicates: this.dupeCount };
  }
}

// ============================================
// SCRAPING LOGIC
// ============================================

async function scrapeQuery(query: SearchQuery): Promise<MetaAd[]> {
  const startTime = Date.now();
  console.log(`[SCRAPE] Starting: "${query.keyword}" in ${query.location || 'USA'}`);
  
  let browser: Browser | null = null;
  
  try {
    // Connect to Bright Data Scraping Browser
    browser = await puppeteer.connect({
      browserWSEndpoint: CONFIG.browserWS,
    });
    
    const page = await browser.newPage();
    
    // Set viewport
    await page.setViewport({ width: 1366, height: 768 });
    
    // Build search URL
    const searchTerm = query.location 
      ? `${query.keyword} ${query.location}` 
      : query.keyword;
    const url = `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=US&q=${encodeURIComponent(searchTerm)}`;
    
    // Navigate with extended timeout
    console.log(`[SCRAPE] Navigating to Ad Library...`);
    await page.goto(url, { 
      waitUntil: 'networkidle2', 
      timeout: 60000 
    });
    
    // Wait for ads to appear
    const adsLoaded = await page.waitForSelector('div[role="article"]', { 
      timeout: 15000 
    }).then(() => true).catch(() => false);
    
    if (!adsLoaded) {
      // Check for "no results"
      const content = await page.content();
      if (content.includes('No ads match') || content.includes('no results')) {
        console.log(`[SCRAPE] No ads found for "${query.keyword}"`);
        return [];
      }
      console.log(`[SCRAPE] Warning: Ads may not have loaded for "${query.keyword}"`);
    }
    
    // Scroll to load more ads
    console.log(`[SCRAPE] Scrolling to load more ads...`);
    let previousCount = 0;
    let noChangeCount = 0;
    
    for (let i = 0; i < CONFIG.scrollAttempts && noChangeCount < 3; i++) {
      // Get current count
      const currentCount = await page.evaluate(() => {
        return document.querySelectorAll('div[role="article"]').length;
      });
      
      if (currentCount >= CONFIG.maxAdsPerQuery) {
        console.log(`[SCRAPE] Reached max ads limit: ${currentCount}`);
        break;
      }
      
      if (currentCount === previousCount) {
        noChangeCount++;
      } else {
        noChangeCount = 0;
        console.log(`[SCRAPE] Loaded ${currentCount} ads...`);
      }
      
      previousCount = currentCount;
      
      // Scroll down
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      await new Promise(r => setTimeout(r, CONFIG.scrollDelay));
      
      // Try clicking "See more" button if exists
      try {
        const seeMore = await page.$('div[role="button"]:has-text("See more")');
        if (seeMore) await seeMore.click();
      } catch (e) {
        // No button, continue
      }
    }
    
    // Extract ads
    console.log(`[SCRAPE] Extracting ad data...`);
    const ads = await page.evaluate((searchQuery) => {
      const results: any[] = [];
      const cards = document.querySelectorAll('div[role="article"]');
      
      cards.forEach((card, index) => {
        try {
          // Page name
          const pageNameEl = card.querySelector('h3') || 
                            card.querySelector('a[href*="/ads/library/?active_status"]') ||
                            card.querySelector('span[dir="auto"]');
          const pageName = pageNameEl?.textContent?.trim() || 'Unknown';
          
          // Page ID from link
          let pageId = '';
          const pageLink = card.querySelector('a[href*="page_id="]');
          if (pageLink) {
            const href = pageLink.getAttribute('href') || '';
            const match = href.match(/page_id=(\d+)/);
            if (match) pageId = match[1];
          }
          
          // Profile picture
          const profileImg = card.querySelector('img[src*="scontent"]');
          const profilePicture = profileImg?.getAttribute('src') || '';
          
          // Ad text
          const textContainer = card.querySelector('div[style*="webkit-line-clamp"]') ||
                               card.querySelector('div[data-testid="ad_archive_renderer_card_body"]');
          const adText = textContainer?.textContent?.trim() || '';
          
          // Media
          const images = Array.from(card.querySelectorAll('img:not([src*="scontent"])')).map(img => 
            img.getAttribute('src') || ''
          ).filter(src => src && !src.includes('emoji') && !src.includes('static'));
          
          const videos = Array.from(card.querySelectorAll('video')).map(v => 
            v.getAttribute('src') || v.querySelector('source')?.getAttribute('src') || ''
          ).filter(Boolean);
          
          const mediaUrls = [...images, ...videos];
          
          let mediaType: string = 'none';
          if (videos.length > 0) mediaType = 'video';
          else if (images.length > 1) mediaType = 'carousel';
          else if (images.length === 1) mediaType = 'image';
          
          // Date info
          const cardText = card.textContent || '';
          const startMatch = cardText.match(/Started running on ([A-Za-z]+ \d+, \d+)/);
          const startDate = startMatch ? startMatch[1] : '';
          const isActive = !cardText.includes('Inactive');
          
          // Platforms
          const platforms: string[] = [];
          if (cardText.includes('Facebook')) platforms.push('facebook');
          if (cardText.includes('Instagram')) platforms.push('instagram');
          if (cardText.includes('Messenger')) platforms.push('messenger');
          if (platforms.length === 0) platforms.push('facebook');
          
          // Spend
          let spendLower, spendUpper;
          const spendMatch = cardText.match(/\$(\d+(?:,\d+)?)\s*-\s*\$(\d+(?:,\d+)?)/);
          if (spendMatch) {
            spendLower = parseInt(spendMatch[1].replace(/,/g, ''));
            spendUpper = parseInt(spendMatch[2].replace(/,/g, ''));
          }
          
          // CTA
          const ctaButton = card.querySelector('a[role="button"], div[role="button"]');
          const ctaText = ctaButton?.textContent?.trim() || '';
          
          // Generate ID
          const adId = (pageId || pageName.replace(/\s/g, '_')) + '_' + Date.now() + '_' + index;
          
          results.push({
            ad_id: adId,
            ad_fingerprint: '', // Will be set later
            page_id: pageId,
            page_name: pageName,
            page_profile_picture_url: profilePicture,
            ad_text: adText,
            media_type: mediaType,
            media_urls: mediaUrls,
            cta_text: ctaText,
            ad_delivery_start_time: startDate,
            is_active: isActive,
            platforms: platforms,
            spend_lower: spendLower,
            spend_upper: spendUpper,
            search_query: searchQuery.keyword,
            search_location: searchQuery.location || '',
            scraped_at: new Date().toISOString(),
            source_url: window.location.href,
          });
        } catch (e) {
          // Skip malformed card
        }
      });
      
      return results;
    }, query);
    
    // Add fingerprints
    const adsWithFingerprints = ads.map(ad => {
      ad.ad_fingerprint = generateFingerprint(ad);
      return ad as MetaAd;
    });
    
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`[SCRAPE] Done: "${query.keyword}" - ${adsWithFingerprints.length} ads in ${elapsed}s`);
    
    return adsWithFingerprints.slice(0, CONFIG.maxAdsPerQuery);
    
  } catch (error) {
    console.error(`[SCRAPE] Error for "${query.keyword}":`, error);
    return [];
  } finally {
    if (browser) {
      try {
        await browser.close();
      } catch (e) {
        // Ignore close errors
      }
    }
  }
}

// ============================================
// WEBHOOK
// ============================================

async function sendToWebhook(ads: MetaAd[], query: SearchQuery, batchNum: number): Promise<boolean> {
  if (!CONFIG.webhookUrl || ads.length === 0) return true;
  
  try {
    const response = await fetch(CONFIG.webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ads,
        query,
        batchNumber: batchNum,
        timestamp: new Date().toISOString(),
      }),
    });
    
    if (response.ok) {
      console.log(`[WEBHOOK] Sent batch ${batchNum}: ${ads.length} ads`);
      return true;
    } else {
      console.error(`[WEBHOOK] Failed: ${response.status}`);
      return false;
    }
  } catch (error) {
    console.error(`[WEBHOOK] Error:`, error);
    return false;
  }
}

// ============================================
// MAIN
// ============================================

async function main() {
  console.log('============================================');
  console.log('  META ADS LIBRARY SCRAPER - BRIGHT DATA');
  console.log('============================================');
  
  // Define your search queries here
  const queries: SearchQuery[] = [
    { keyword: 'plumber', location: 'Ocala, FL' },
    { keyword: 'hvac', location: 'Ocala, FL' },
    { keyword: 'electrician', location: 'Ocala, FL' },
    { keyword: 'roofing', location: 'Ocala, FL' },
    { keyword: 'landscaping', location: 'Ocala, FL' },
    { keyword: 'pest control', location: 'Ocala, FL' },
    { keyword: 'cleaning service', location: 'Ocala, FL' },
    { keyword: 'lawn care', location: 'Ocala, FL' },
    { keyword: 'pool service', location: 'Ocala, FL' },
    { keyword: 'garage door', location: 'Ocala, FL' },
  ];
  
  console.log(`\nQueries: ${queries.length}`);
  console.log(`Concurrency: ${CONFIG.concurrency}`);
  console.log(`Max ads per query: ${CONFIG.maxAdsPerQuery}`);
  console.log(`Webhook: ${CONFIG.webhookUrl || 'Not configured (saving locally)'}`);
  console.log('============================================\n');
  
  const startTime = Date.now();
  const allAds: MetaAd[] = [];
  const deduper = new DedupeTracker();
  let batchNumber = 0;
  let queriesCompleted = 0;
  
  // Process in batches based on concurrency
  for (let i = 0; i < queries.length; i += CONFIG.concurrency) {
    const batch = queries.slice(i, i + CONFIG.concurrency);
    
    console.log(`\n--- Batch ${Math.floor(i / CONFIG.concurrency) + 1}/${Math.ceil(queries.length / CONFIG.concurrency)} ---`);
    
    // Run batch concurrently
    const results = await Promise.all(batch.map(q => scrapeQuery(q)));
    
    // Process results
    for (let j = 0; j < results.length; j++) {
      const ads = results[j];
      const query = batch[j];
      
      // Deduplicate
      const uniqueAds = ads.filter(ad => deduper.isNew(ad));
      allAds.push(...uniqueAds);
      
      // Send to webhook in batches
      if (CONFIG.webhookUrl && uniqueAds.length > 0) {
        for (let k = 0; k < uniqueAds.length; k += CONFIG.webhookBatchSize) {
          batchNumber++;
          const webhookBatch = uniqueAds.slice(k, k + CONFIG.webhookBatchSize);
          await sendToWebhook(webhookBatch, query, batchNumber);
        }
      }
      
      queriesCompleted++;
    }
    
    // Progress update
    const elapsed = (Date.now() - startTime) / 1000 / 60;
    const adsPerMin = allAds.length / elapsed;
    console.log(`\n[PROGRESS] ${queriesCompleted}/${queries.length} queries | ${allAds.length} unique ads | ${adsPerMin.toFixed(0)} ads/min`);
  }
  
  // Save to file
  const fs = await import('fs');
  fs.writeFileSync(CONFIG.outputFile, JSON.stringify(allAds, null, 2));
  
  // Final stats
  const totalTime = (Date.now() - startTime) / 1000 / 60;
  const stats = deduper.stats;
  
  console.log('\n============================================');
  console.log('  SCRAPING COMPLETE');
  console.log('============================================');
  console.log(`Total time: ${totalTime.toFixed(1)} minutes`);
  console.log(`Queries processed: ${queriesCompleted}`);
  console.log(`Total unique ads: ${stats.unique}`);
  console.log(`Duplicates skipped: ${stats.duplicates}`);
  console.log(`Ads per minute: ${(stats.unique / totalTime).toFixed(0)}`);
  console.log(`Saved to: ${CONFIG.outputFile}`);
  console.log('============================================');
}

// Run
main().catch(console.error);
